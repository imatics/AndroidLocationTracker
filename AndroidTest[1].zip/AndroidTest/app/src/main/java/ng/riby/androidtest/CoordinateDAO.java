package ng.riby.androidtest;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

@Dao
public interface CoordinateDAO  {



    @Query("Select * from displacement where position = 'origin'")
    Coordinate getOrigin();

    @Query("Select * from displacement where position = 'destination'")
    Coordinate getDestination();


    @Insert
    void insertCoordinate(Coordinate coord);


    @Delete
    void deleteCoordinate(Coordinate coord);




}
