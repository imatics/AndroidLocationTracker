package ng.riby.androidtest;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LocationListener {

    public static int STATE = 0;
    int STATE_SCANNING = 1;
    int STATE_IDLE = 0;
    static boolean permissionGranted = false;
    static int requestCode = 123;

    private static final String API_KEY = "AIzaSyD6mAOR2Bp-obgXHVCb_iyhTbQliRfhFZM";
    private static String url = "https://maps.googleapis.com/maps/api/distancematrix/json?";

    Button startScan, stopScan;
    LocationManager locationManager;
    Location origin, destination;
    TextView originTv, destinationTv, distanceTv, stateTv, currentTV;
    int checkVal;
    String[] states = new String[]{"Idle", "Tracking"};

    Database database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startScan = (Button) findViewById(R.id.start_scan);
        stopScan = (Button) findViewById(R.id.stop_scan);

        originTv = (TextView) findViewById(R.id.origin);
        destinationTv = (TextView) findViewById(R.id.dest);
        distanceTv = (TextView) findViewById(R.id.distance);

        stateTv = (TextView) findViewById(R.id.state);

//        stateTv.setText(states[STATE]);
        stateTv.setText("Status : "+states[STATE]);

        final String locationPermission = Manifest.permission.ACCESS_FINE_LOCATION;
        checkVal = checkCallingOrSelfPermission(locationPermission);
        database = Database.getInstance(this);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        // check is the user granted gps access permission
        if (checkSelfPermission(locationPermission) == PackageManager.PERMISSION_GRANTED){
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0,0, this);
        permissionGranted = true;
        }else {
            // show dialog prompting the user to grant gps access permission
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, requestCode);
        }
        stopScan.setEnabled(false);





        startScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)){
                    Toast.makeText(MainActivity.this,"Enable Location and try again", Toast.LENGTH_SHORT).show();
                    return;
                }

                STATE = STATE_SCANNING;
                stateTv.setText("Status : "+states[STATE]);
                startScan.setEnabled(false);
                stopScan.setEnabled(true);
                distanceTv.setVisibility(View.INVISIBLE);
                destinationTv.setVisibility(View.INVISIBLE);
                if (permissionGranted) {
                    origin = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    Toast.makeText(MainActivity.this, "lat: " + origin.getLatitude() + " long: " + origin.getLongitude(), Toast.LENGTH_LONG).show();
                    originTv.setText("Origin: " + "lat " + origin.getLatitude() + ", long " + origin.getLongitude());
                    Coordinate c = new Coordinate();
                    c.setLatitude(origin.getLatitude());
                    c.setLongitude(origin.getLongitude());
                    c.setPosition("origin");
                    insert(c);
                } else
                    Toast.makeText(MainActivity.this, "Enable Permission first", Toast.LENGTH_LONG).show();


            }
        });

        stopScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)){
                    Toast.makeText(MainActivity.this,"Enable Location and try again", Toast.LENGTH_SHORT).show();
                    return;
                }


                STATE = STATE_IDLE;
                stateTv.setText("Track state : "+states[STATE]);
                stopScan.setEnabled(false);
                startScan.setEnabled(true);
                if (permissionGranted) {
                    destination = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    Toast.makeText(MainActivity.this, "lat: " + destination.getLatitude() + " long: " + destination.getLongitude(), Toast.LENGTH_LONG).show();
                    destinationTv.setText("Destination: " + "lat " + destination.getLatitude() + ", long " + destination.getLongitude());
                    destinationTv.setVisibility(View.VISIBLE);
                    Coordinate c = new Coordinate();
                    c.setLatitude(destination.getLatitude());
                    c.setLongitude(destination.getLongitude());
                    c.setPosition("destination");
                    insert(c);
                    calculateDistance();
                } else
                    Toast.makeText(MainActivity.this, "Enable Permission first", Toast.LENGTH_LONG).show();

            }
        });
    }


    public void insert(final Coordinate c) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                if (c.getPosition().equalsIgnoreCase("origin")) {
                    Coordinate oidc = database.coordinateDAO().getOrigin();
                    if (oidc != null) {
                        database.coordinateDAO().deleteCoordinate(oidc);
                    }
                    database.coordinateDAO().insertCoordinate(c);
                } else if (c.getPosition().equalsIgnoreCase("destination")) {
                    Coordinate oidc = database.coordinateDAO().getDestination();
                    if (oidc != null) {
                        database.coordinateDAO().deleteCoordinate(oidc);
                    }
                    database.coordinateDAO().insertCoordinate(c);

                }

            }
        }).start();
    }

    public void calculateDistance() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Coordinate o = database.coordinateDAO().getOrigin();
                Coordinate d = database.coordinateDAO().getDestination();

                try {
                    String data = getHTTPData(url
                            + "origins=" + o.getLatitude() + "," + o.getLongitude()
                            + "&destinations=" + d.getLatitude() + "," + d.getLongitude()
                            + "&key=" + API_KEY
                    );

                    if (data == null) {

                    } else {
                        JSONObject json = new JSONObject(data);
                        final String distance = json.getJSONArray("rows").getJSONObject(0).getJSONArray("elements").getJSONObject(0).getJSONObject("distance").getString("text");
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                distanceTv.setText("Distance Covered: " + distance);
                                distanceTv.setVisibility(View.VISIBLE);
                            }
                        });

                    }

                } catch (IOException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        }).start();
    }


    public String getHTTPData(String url) throws Exception {
        URL website = new URL(url);
        HttpURLConnection conn = (HttpURLConnection) website.openConnection();
        conn.setReadTimeout(10000);
        conn.setConnectTimeout(15000);
        conn.setRequestMethod("GET");
        conn.setUseCaches(true);
        conn.setDoInput(true);
        conn.connect();
        if (conn.getResponseCode() == HttpURLConnection.HTTP_OK || conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null)
                sb.append(line);
            return sb.toString();
        } else
            return null;


    }

    @Override
    public void onLocationChanged(Location location) {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
       if (requestCode == MainActivity.requestCode)
        if (grantResults.length>0&&grantResults[0] == PackageManager.PERMISSION_GRANTED){
           permissionGranted = true;
       }


    }
}
