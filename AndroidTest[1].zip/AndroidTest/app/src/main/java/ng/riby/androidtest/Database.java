package ng.riby.androidtest;

import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

@android.arch.persistence.room.Database(entities = Coordinate.class, exportSchema = false, version = 1)
public abstract class Database extends RoomDatabase {

    private static final String DB_NAME = "journey.db";
    private static Database instance;

    public static synchronized Database getInstance(Context context){
        if (instance==null){
            instance = Room.databaseBuilder(context.getApplicationContext(),Database.class,DB_NAME)
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }

    public abstract CoordinateDAO coordinateDAO();

}
